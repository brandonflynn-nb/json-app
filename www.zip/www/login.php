<?php
session_start();
    if(isset($_POST['email']) && isset($_POST['password']))
    {
        // Load user-data.json
        $userData = file_get_contents("user-data.json");
        $userDataDecoded = json_decode($userData, true);
        $success = false;

        // itterate through user-data
        foreach($userDataDecoded as $users)
        {   
            // find matching email
            if($_POST['email'] == $users['email'] 
                && $users["password"] == md5($_POST['password']))
            {
                $success = true;
                break;
            }
        }

        if($success)
        {
            //log in
            $_SESSION['username'] = $users['username'];
            $_SESSION['email'] = $users['email'];
            $_SESSION['authenticated'] = $users['authenticated'];
            echo 'true';
        }
        else
        {
            echo 'false';
        }
    }

    if(isset($_GET['logout']))
    {
        session_destroy();
        header('location:/index.php');
    }
?>